import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
    selector: 'app-employer-search-filter',
    templateUrl: './employer-search-filter.component.html',
    styleUrls: ['./employer-search-filter.component.less'],
})
export class EmployerSearchFilterComponent implements OnInit {
    @Input() resumeInfo: any = [];
    @Input() resumeInfoDup: any = [];
    allResumeInfo: any = [];
    @Output() titleFilter = new EventEmitter();
    @Output() dataEmitter= new EventEmitter();
    checkTitleArrry: any = [];
    checkCompanyArrry: any = [];
    checkTitleFilter: boolean = false;
    checkCompanyFilter: boolean = false;
    constructor() { }

    ngOnInit(): void {
       
    }
    onTitleChange(e: any, data: any) {

        let a: any = [];
        // this.checkTitleArrry = [];
        if (e == true) {
            this.checkTitleArrry.push(data);
        }
        else {
            this.checkTitleArrry = this.checkTitleArrry.filter((val: any) => val !== data);
        }
        console.log('filter===>', this.checkTitleArrry);

         let p:any = [];
        
        for (const dev of this.resumeInfo[0].data) {
            for (const group of  this.checkTitleArrry) {
                for (const check of dev[1].workExperienceDetails) {
                    if (group === check.title) {
                        console.log('value:', dev);
                        p.push(dev);
                    }
                }

            }
        }

                        this.dataEmitter.emit(p);

        // this.resumeInfoDup[0]['data'] = [];
        // a.push({data: p});
        // if(p.length >0){
        //     p.map((el:any)=> this.resumeInfoDup[0]['data'].push(el));
        // }

        console.log('dcvhdivh', p);

        console.log('aaaa', this.resumeInfoDup);

    }
    onCompanyChange(e: any, data: any) {
        if (e == true) {
            this.checkCompanyArrry.push(data);
        }
        else {
            this.checkCompanyArrry = this.checkCompanyArrry.filter((val: any) => val !== data);
        }
        console.log(this.resumeInfo);
        console.log(this.checkCompanyArrry);
    }
}