import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-employer-search-resume-contact',
    templateUrl: './employer-search-resume-contact.component.html',
    styleUrls: ['./employer-search-resume-contact.component.less'],
})
export class EmployerSearchResumeContactComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
