import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employer-search-resume',
  templateUrl: './employer-search-resume.component.html',
  styleUrls: ['./employer-search-resume.component.less']
})
export class EmployerSearchResumeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
